"""
Minimal OpenAI + Anthropic reverse proxy for Replit.
Clients authenticate with PROXY_API_KEY (Bearer or x-api-key).
Upstream uses OPENAI_API_KEY / ANTHROPIC_API_KEY from the environment (Replit-managed or Secrets).
"""

from __future__ import annotations

import hmac
import os
import json
import traceback
from typing import AsyncIterator
from urllib.parse import urlparse

import httpx
from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.responses import StreamingResponse

PROXY_API_KEY = os.environ.get("PROXY_API_KEY", "").strip()

# Support both direct keys and Replit-managed AI Integration keys
OPENAI_API_KEY = (
    os.environ.get("OPENAI_API_KEY", "")
    or os.environ.get("AI_INTEGRATIONS_OPENAI_API_KEY", "")
).strip()
ANTHROPIC_API_KEY = (
    os.environ.get("ANTHROPIC_API_KEY", "")
    or os.environ.get("AI_INTEGRATIONS_ANTHROPIC_API_KEY", "")
).strip()

# Replit-managed integration base URL does NOT use a /v1 prefix in its path;
# standard OpenAI does. Detection rule: if the resolved base URL already contains
# a non-trivial path (e.g. /modelfarm/openai), treat it as integration-style and
# skip /v1. Plain domain-only URL -> prepend /v1.
_ai_integration_base = os.environ.get("AI_INTEGRATIONS_OPENAI_BASE_URL", "").rstrip("/")
if _ai_integration_base:
    # Dev: Replit injects this directly, no /v1 needed
    OPENAI_BASE = _ai_integration_base
    OPENAI_V1_PREFIX = ""
else:
    _custom_base = os.environ.get("OPENAI_BASE_URL", "https://api.openai.com").rstrip("/")
    OPENAI_BASE = _custom_base
    # If OPENAI_BASE_URL already has a path (e.g. http://localhost:1106/modelfarm/openai),
    # it's an integration-style URL that doesn't use /v1.
    _parsed_path = urlparse(_custom_base).path.strip("/")
    OPENAI_V1_PREFIX = "" if _parsed_path else "/v1"

# Anthropic base URL: prefer Replit-managed integration URL, then explicit override, then default.
ANTHROPIC_BASE = (
    os.environ.get("AI_INTEGRATIONS_ANTHROPIC_BASE_URL")
    or os.environ.get("ANTHROPIC_BASE_URL", "https://api.anthropic.com")
).rstrip("/")

app = FastAPI(title="Replit AI proxy")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _client_proxy_token(request: Request) -> str | None:
    auth = request.headers.get("authorization") or ""
    if auth.lower().startswith("bearer "):
        return auth[7:].strip()
    xk = request.headers.get("x-api-key")
    if xk:
        return xk.strip()
    return None


def require_proxy_auth(request: Request) -> None:
    if not PROXY_API_KEY:
        raise HTTPException(
            status_code=503,
            detail="PROXY_API_KEY is not set. Add it in Replit Secrets.",
        )
    token = _client_proxy_token(request)
    if not token or not hmac.compare_digest(token, PROXY_API_KEY):
        raise HTTPException(status_code=401, detail="Invalid or missing API key")


def _anthropic_error(status_code: int, message: str, error_type: str) -> JSONResponse:
    # Claude Code expects Anthropic-style error envelopes; returning FastAPI's default
    # {"detail": "..."} can cause client-side parsing issues.
    return JSONResponse(
        status_code=status_code,
        content={
            "type": "error",
            "error": {
                "type": error_type,
                "message": message,
            },
        },
    )


def _hop_by_hop() -> set[str]:
    return {
        "connection",
        "keep-alive",
        "proxy-authenticate",
        "proxy-authorization",
        "te",
        "trailers",
        "transfer-encoding",
        "upgrade",
        "host",
        "content-length",
    }


def _forward_headers(request: Request, upstream_auth: dict[str, str]) -> dict[str, str]:
    out: dict[str, str] = {}
    hop = _hop_by_hop()
    for name, value in request.headers.items():
        ln = name.lower()
        if ln in hop or ln in ("authorization", "x-api-key"):
            continue
        out[name] = value
    out.update(upstream_auth)
    return out


@app.get("/")
@app.get("/health")
async def health() -> dict:
    return {
        "ok": True,
        "openai_configured": bool(OPENAI_API_KEY),
        "anthropic_configured": bool(ANTHROPIC_API_KEY),
        "proxy_key_configured": bool(PROXY_API_KEY),
    }


@app.api_route("/v1/messages", methods=["POST", "OPTIONS"])
async def anthropic_messages(request: Request) -> Response:
    if request.method == "OPTIONS":
        return Response(status_code=204)
    try:
        require_proxy_auth(request)
    except HTTPException as e:
        if e.status_code == 401:
            return _anthropic_error(401, str(e.detail), "authentication_error")
        return _anthropic_error(int(e.status_code), str(e.detail), "api_error")

    if not ANTHROPIC_API_KEY:
        return _anthropic_error(
            503,
            "ANTHROPIC_API_KEY is not set. Enable Anthropic (Replit managed) or add a Secret.",
            "api_error",
        )

    url = f"{ANTHROPIC_BASE}/v1/messages"
    if request.url.query:
        url = f"{url}?{request.url.query}"

    ver = request.headers.get("anthropic-version", "2023-06-01")
    headers = _forward_headers(
        request,
        {
            "x-api-key": ANTHROPIC_API_KEY,
            "anthropic-version": ver,
        },
    )
    original_body = await request.body()
    try:
        json_body = json.loads(original_body)
        if "temperature" in json_body and "top_p" in json_body:
            # According to the error, both cannot be specified.
            # We'll prioritize 'temperature' and remove 'top_p'.
            # This is a common heuristic, as 'temperature' is often the primary control.
            del json_body["top_p"]
            modified_body = json.dumps(json_body).encode("utf-8")
        else:
            modified_body = original_body
    except json.JSONDecodeError:
        # If the body is not JSON, or malformed, pass it as is.
        # This might happen for other content types, though unlikely for messages endpoint.
        modified_body = original_body

    return await _proxy_httpx(request.method, url, headers, modified_body, target_api_type="anthropic")


@app.api_route("/v1/{subpath:path}", methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"])
async def openai_forward(request: Request, subpath: str) -> Response:
    if request.method == "OPTIONS":
        return Response(status_code=204)
    require_proxy_auth(request)
    if not OPENAI_API_KEY:
        raise HTTPException(
            status_code=503,
            detail="OPENAI_API_KEY is not set. Enable OpenAI (Replit managed) or add a Secret.",
        )

    # Build upstream URL: managed integration has no /v1 in its path; standard OpenAI does.
    url = f"{OPENAI_BASE}{OPENAI_V1_PREFIX}/{subpath}"
    if request.url.query:
        url = f"{url}?{request.url.query}"

    headers = _forward_headers(
        request, {"Authorization": f"Bearer {OPENAI_API_KEY}"}
    )
    body = await request.body()

    return await _proxy_httpx(request.method, url, headers, body, target_api_type="openai")


async def _proxy_httpx(
    method: str, url: str, headers: dict[str, str], body: bytes, target_api_type: str | None = None
) -> Response:
    timeout = httpx.Timeout(connect=30.0, read=600.0, write=60.0, pool=30.0)

    client_kwargs = {"timeout": timeout}
    if target_api_type == "anthropic":
        client_kwargs["http2"] = False  # Try disabling HTTP/2 for Anthropic

    async with httpx.AsyncClient(**client_kwargs) as client:
        req = client.build_request(method, url, headers=headers, content=body)
        resp = await client.send(req, stream=True)
        streamed = False
        try:
            out_headers = {
                k: v
                for k, v in resp.headers.items()
                if k.lower() not in _hop_by_hop()
            }

            resp_ct = (resp.headers.get("content-type") or "").lower()
            is_stream = (
                "text/event-stream" in resp_ct
                or "application/x-ndjson" in resp_ct
                or "application/stream+json" in resp_ct
            )
            media_type = resp.headers.get("content-type")

            if is_stream:
                streamed = True

                async def gen() -> AsyncIterator[bytes]:
                    print("Starting Anthropic response streaming...")
                    print(f"Anthropic Response Headers: {resp.headers}")
                    try:
                        async for chunk in resp.aiter_bytes():
                            print(f"Received Anthropic stream chunk of size: {len(chunk)}")
                            yield chunk
                        print("Finished Anthropic response streaming successfully.")
                    except httpx.StreamError as e:
                            print(f"Error during Anthropic response streaming: {type(e).__name__}: {e!r}")
                            print(f"Response object closed state: {resp.is_closed}")
                            print(traceback.format_exc())
                            # If ReadError occurs, it means the stream broke. Send an Anthropic-style error.
                            # The client expects event-stream format, so we need to wrap it.
                            error_message = f"Error: Stream interrupted during Anthropic API response. Details: {e!r}"
                            error_json = {"type": "error", "error": {"type": "internal_error", "message": error_message}}
                            yield f"data: {json.dumps(error_json)}\n\n".encode('utf-8')
                        except Exception as e:
                            print(f"Error during Anthropic response streaming: {type(e).__name__}: {e!r}")
                            print(f"Response object closed state: {resp.is_closed}")
                    finally:
                        await resp.aclose()

                # Let StreamingResponse set Content-Type via media_type.
                out_headers.pop("content-type", None)
                return StreamingResponse(
                    gen(),
                    status_code=resp.status_code,
                    headers=dict(out_headers),
                    media_type=media_type,
                )

            content = await resp.aread()
            return Response(
                content=content,
                status_code=resp.status_code,
                headers=dict(out_headers),
            )
        finally:
            # If we streamed the response, the generator is responsible for closing it.
            if not streamed and not resp.is_closed:
                await resp.aclose()


if __name__ == "__main__":
    import uvicorn

    port = int(os.environ.get("PORT", "5000"))
    uvicorn.run("main:app", host="0.0.0.0", port=port, proxy_headers=True)
