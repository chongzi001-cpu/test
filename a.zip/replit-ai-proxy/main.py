"""
Minimal OpenAI + Anthropic reverse proxy for Replit.
Clients authenticate with PROXY_API_KEY (Bearer or x-api-key).
Upstream uses OPENAI_API_KEY / ANTHROPIC_API_KEY from the environment (Replit-managed or Secrets).
"""

from __future__ import annotations

import hmac
import os
from typing import AsyncIterator

import httpx
from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse

PROXY_API_KEY = os.environ.get("PROXY_API_KEY", "").strip()
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "").strip()
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "").strip()
OPENAI_BASE = os.environ.get("OPENAI_BASE_URL", "https://api.openai.com").rstrip("/")
ANTHROPIC_BASE = os.environ.get("ANTHROPIC_BASE_URL", "https://api.anthropic.com").rstrip("/")

app = FastAPI(title="Replit AI proxy")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _client_proxy_token(request: Request) -> str | None:
    auth = request.headers.get("authorization") or ""
    if auth.lower().startswith("bearer "):
        return auth[7:].strip()
    xk = request.headers.get("x-api-key")
    if xk:
        return xk.strip()
    return None


def require_proxy_auth(request: Request) -> None:
    if not PROXY_API_KEY:
        raise HTTPException(
            status_code=503,
            detail="PROXY_API_KEY is not set. Add it in Replit Secrets.",
        )
    token = _client_proxy_token(request)
    if not token or not hmac.compare_digest(token, PROXY_API_KEY):
        raise HTTPException(status_code=401, detail="Invalid or missing API key")


def _hop_by_hop() -> set[str]:
    return {
        "connection",
        "keep-alive",
        "proxy-authenticate",
        "proxy-authorization",
        "te",
        "trailers",
        "transfer-encoding",
        "upgrade",
        "host",
        "content-length",
    }


def _forward_headers(request: Request, upstream_auth: dict[str, str]) -> dict[str, str]:
    out: dict[str, str] = {}
    hop = _hop_by_hop()
    for name, value in request.headers.items():
        ln = name.lower()
        if ln in hop or ln in ("authorization", "x-api-key"):
            continue
        out[name] = value
    out.update(upstream_auth)
    return out


@app.get("/")
@app.get("/health")
async def health() -> dict:
    return {
        "ok": True,
        "openai_configured": bool(OPENAI_API_KEY),
        "anthropic_configured": bool(ANTHROPIC_API_KEY),
        "proxy_key_configured": bool(PROXY_API_KEY),
    }


@app.api_route("/v1/messages", methods=["POST", "OPTIONS"])
async def anthropic_messages(request: Request) -> Response:
    if request.method == "OPTIONS":
        return Response(status_code=204)
    require_proxy_auth(request)
    if not ANTHROPIC_API_KEY:
        raise HTTPException(
            status_code=503,
            detail="ANTHROPIC_API_KEY is not set. Enable Anthropic (Replit managed) or add a Secret.",
        )

    url = f"{ANTHROPIC_BASE}/v1/messages"
    if request.url.query:
        url = f"{url}?{request.url.query}"

    ver = request.headers.get("anthropic-version", "2023-06-01")
    headers = _forward_headers(
        request,
        {
            "x-api-key": ANTHROPIC_API_KEY,
            "anthropic-version": ver,
        },
    )
    body = await request.body()

    return await _proxy_httpx(request.method, url, headers, body)


@app.api_route("/v1/{subpath:path}", methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"])
async def openai_forward(request: Request, subpath: str) -> Response:
    if request.method == "OPTIONS":
        return Response(status_code=204)
    require_proxy_auth(request)
    if not OPENAI_API_KEY:
        raise HTTPException(
            status_code=503,
            detail="OPENAI_API_KEY is not set. Enable OpenAI (Replit managed) or add a Secret.",
        )

    url = f"{OPENAI_BASE}/v1/{subpath}"
    if request.url.query:
        url = f"{url}?{request.url.query}"

    headers = _forward_headers(
        request, {"Authorization": f"Bearer {OPENAI_API_KEY}"}
    )
    body = await request.body()

    return await _proxy_httpx(request.method, url, headers, body)


async def _proxy_httpx(
    method: str, url: str, headers: dict[str, str], body: bytes
) -> Response:
    want_stream = False
    ct = headers.get("content-type", "")
    if "application/json" in ct.lower() and body:
        try:
            import json

            payload = json.loads(body)
            want_stream = bool(payload.get("stream"))
        except (json.JSONDecodeError, TypeError):
            pass

    timeout = httpx.Timeout(connect=30.0, read=600.0, write=60.0, pool=30.0)

    async with httpx.AsyncClient(timeout=timeout) as client:
        if want_stream:
            req = client.build_request(method, url, headers=headers, content=body)
            resp = await client.send(req, stream=True)

            async def gen() -> AsyncIterator[bytes]:
                try:
                    async for chunk in resp.aiter_bytes():
                        yield chunk
                finally:
                    await resp.aclose()

            out_headers = {
                k: v
                for k, v in resp.headers.items()
                if k.lower() not in _hop_by_hop()
            }
            return StreamingResponse(
                gen(),
                status_code=resp.status_code,
                headers=dict(out_headers),
            )

        resp = await client.request(method, url, headers=headers, content=body)
        out_headers = {
            k: v
            for k, v in resp.headers.items()
            if k.lower() not in _hop_by_hop()
        }
        return Response(
            content=resp.content,
            status_code=resp.status_code,
            headers=dict(out_headers),
        )


if __name__ == "__main__":
    import uvicorn

    port = int(os.environ.get("PORT", "8000"))
    uvicorn.run("main:app", host="0.0.0.0", port=port, proxy_headers=True)
